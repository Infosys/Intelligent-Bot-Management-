using System;
using System.Collections.Generic;
using System.Text;

namespace Infosys.Lif.LegacyWorkbench
{
    internal static class Constants
    {

        internal static string[] File_Name_Seperators = { ";" };

        internal const string File_Seperator = ";";
    }
}
